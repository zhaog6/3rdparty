#define OMPI_SKIP_MPICXX 1
#define MPICH_SKIP_MPICXX 1
#include <htool/htool.hpp>

int main(int, char *[]) {
    return 0;
}