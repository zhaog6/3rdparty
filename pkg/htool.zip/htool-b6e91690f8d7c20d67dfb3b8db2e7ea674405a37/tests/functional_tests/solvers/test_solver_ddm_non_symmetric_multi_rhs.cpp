#include "test_solver_ddm.hpp"

int main(int argc, char *argv[]) {
    return test_solver_ddm(argc, argv, 10, 'N');
}