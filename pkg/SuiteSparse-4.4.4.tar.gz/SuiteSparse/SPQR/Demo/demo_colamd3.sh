./qrdemo_gpu3 A.mtx 2 > o_colamd_nogpu
